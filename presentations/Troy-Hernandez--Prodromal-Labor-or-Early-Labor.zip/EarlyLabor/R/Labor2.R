dat <- read.csv("~/ToDo/Contraction_Clean.csv", stringsAsFactors = F)
dat$posix <- as.POSIXct(dat$posix)
# head(dat)
# plot(x = dat$posix, y = dat$duration)
# plot(x = dat$posix, y = dat$frequency)
# 
# plot(x = dat$posix, y = dat$frequency * 60)
# plot(x = dat$posix, y = dat$duration)
# 
# mean(dat$frequency[1:15])
# mean(dat$frequency[16:40])

# dat$frequency <- dat$frequency * 60

# Modeling
mod.duration <- lm(duration~posix, data = dat)
mod.frequency <- lm(frequency~posix, data = dat)

#tomorrow
seq.posix <- seq(dat$posix[56], by = "sec", length.out = 86400)
duration.freq.diff <- predict(mod.duration, newdata = data.frame(posix = seq.posix)) -
  predict(mod.frequency, newdata = data.frame(posix = seq.posix))


# 5-1-1
freq.diff.511 <- 300 - predict(mod.frequency,
                               newdata = data.frame(posix = seq.posix))
time.511 <- seq.posix[which.min(abs(freq.diff.511))]
time.511
duration.511 <- predict(mod.duration, newdata = data.frame(posix = time.511))
duration.511


# 3-1-1
freq.diff.311 <- 180 - predict(mod.frequency,
                               newdata = data.frame(posix = seq.posix))
time.311 <- seq.posix[which.min(abs(freq.diff.311))]
time.311
duration.311 <- predict(mod.duration, newdata = data.frame(posix = time.311))
duration.311

# birth <- seq.posix[which.min(abs(duration.freq.diff))]
birth.ind <- which.min(abs(duration.freq.diff))

dat.plot <- data.frame(posix = dat$posix, duration = dat$duration, frequency = dat$frequency)
dat.plot <- data.frame(rbind(dat.plot,
                             c(birth,
                               predict(mod.duration, newdata = data.frame(posix = birth)),
                               predict(mod.frequency, newdata = data.frame(posix = birth)))))
dat.plot$posix <- as.POSIXct(dat.plot$posix, origin = "1970-01-01")

#####################################################
# Plot
par(family = "Open Sans")

plot(x = dat.plot$posix, y = dat.plot$frequency,
     ylim = c(min(dat.plot$duration, dat.plot$frequency),
              max(dat.plot$duration, dat.plot$frequency)),
     xlab = "Date/Time", ylab = "Length (s)", main = "Labor Frequency/Duration",
     col = c(rep("#DF536B", nrow(dat.plot) - 1), "#D03AF5"),
     pch = c(rep(6, nrow(dat.plot) - 1), 8))
points(x = dat.plot$posix, y = dat.plot$duration,
       col = c(rep("#61D04F", nrow(dat.plot) - 1), "#D03AF5"),
       pch = c(rep(2, nrow(dat.plot) - 1), 8))
abline(a = mod.frequency$coefficients[1], b = mod.frequency$coefficients[2],
       col = "#DF536B", lty = 2)
abline(a = mod.duration$coefficients[1], b = mod.duration$coefficients[2],
       col = "#61D04F", lty = 2)

# 5-2-1 line
abline(v = time.511, col = "gray62", lty = 2)

# 3-2-1 line
abline(v = time.311, col = "#EEC21F", lty = 2)

legend("topright", legend = c("Frequency", "Duration",
                              "5-2-1", "3-2-1", "Est. Birth"),
       col = c("#DF536B", "#61D04F", "gray62", "#EEC21F", "#D03AF5"),
       lty = c(2, 2, 2, 2, 0), pch = c(6, 2, -1, -1, 8))
# text.str <- paste0(substr(posix, 1, 10), "\n", substr(posix, 12, 23), " CDT")
text(x = birth - 1800, y = predict(mod.frequency, birth) - 75,
     labels = substr(birth, 1, 10), cex = .65)
text(x = birth - 1800, y = predict(mod.frequency, birth) - 125,
     labels = paste0(substr(birth, 12, 16), " CDT"), cex = .65)

text(x = time.311 - 8000, y = 800, col = "#EEC21F",
     labels = paste0(substr(time.311, 12, 16), " CDT"), cex = .65)

text(x = time.511 - 8000, y = 800, col = "gray62",
     labels = paste0(substr(time.511, 12, 16), " CDT"), cex = .65)

# write.csv(dat.plot, "Contraction_Clean.csv", row.names = F)
